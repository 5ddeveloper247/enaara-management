@extends('layouts.app')

@section('title', 'Add Role - Admin Panel')

@section('page-title', 'Roles')

@section('content')
    <div class="container-fluid">
        <div class="row align-items-center mb-3">
            <div class="col-md-6">
                <h5 class="mb-0">Add New Role</h5>
            </div>
            <div class="col-md-6 text-end">
                <a href="{{ route('admin.role.index') }}" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Back to Roles
                </a>
            </div>
        </div>

        <div class="card border-0 rounded-4">
            <div class="card-body p-4">
                <form action="{{ route('admin.role.store') }}" method="POST">
                    @csrf
                    <h6 class="mb-3 fw-semibold">
                        <i class="bi bi-shield-check me-2"></i>Role Information
                    </h6>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label for="name" class="form-label">Role Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" required maxlength="255" placeholder="Enter role name">
                            <small class="text-muted">Role name should be unique and descriptive</small>
                            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label for="slug" class="form-label">Slug</label>
                            <input type="text" name="slug" id="slug" class="form-control @error('slug') is-invalid @enderror" value="{{ old('slug') }}" maxlength="255" placeholder="Auto-generated if empty">
                            @error('slug')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-12">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" id="description" class="form-control @error('description') is-invalid @enderror" rows="3" maxlength="500">{{ old('description') }}</textarea>
                            @error('description')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label for="is_active" class="form-label">Status</label>
                            <select name="is_active" id="is_active" class="form-select @error('is_active') is-invalid @enderror">
                                <option value="1" {{ old('is_active', true) ? 'selected' : '' }}>Active</option>
                                <option value="0" {{ old('is_active') === false || old('is_active') === '0' ? 'selected' : '' }}>Inactive</option>
                            </select>
                            @error('is_active')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                    </div>

                    <hr class="my-4">
                    <div class="d-flex align-items-center justify-content-between mb-3">
                        <h6 class="mb-0 fw-semibold">
                            <i class="bi bi-grid me-2"></i>Module Permissions
                        </h6>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="selectAllModules">
                            <label class="form-check-label" for="selectAllModules">Select All Modules</label>
                        </div>
                    </div>
                    @foreach($moduleCategories ?? [] as $category)
                        <div class="mb-4">
                            <h6 class="text-muted small mb-2">{{ $category->category_name ?? 'Uncategorized' }} <span class="fw-normal">({{ $category->modules->count() }} modules)</span></h6>
                            <div class="row g-2">
                                @foreach($category->modules as $module)
                                    <div class="col-md-4 col-lg-3">
                                        <div class="form-check">
                                            <input class="form-check-input module-privilege-cb" type="checkbox" name="module_ids[]" value="{{ $module->id }}" id="module_{{ $module->id }}" {{ in_array($module->id, old('module_ids', [])) ? 'checked' : '' }}>
                                            <label class="form-check-label" for="module_{{ $module->id }}">{{ $module->module_name ?? $module->id }}</label>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                    @if(empty($moduleCategories) || $moduleCategories->isEmpty())
                        <p class="text-muted small">No modules available. Add modules first.</p>
                    @endif

                    <hr class="my-4">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary bg-main border-0">Create Role</button>
                        <a href="{{ route('admin.role.index') }}" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('selectAllModules')?.addEventListener('change', function() {
            document.querySelectorAll('.module-privilege-cb').forEach(function(cb) {
                cb.checked = this.checked;
            }, this);
        });
    </script>
@endsection
